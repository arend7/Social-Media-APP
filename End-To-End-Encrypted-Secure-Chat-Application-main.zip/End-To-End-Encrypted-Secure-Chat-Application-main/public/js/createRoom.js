const room = document.getElementById("room");
const roomKey = document.querySelector(".key");

console.log(room);
console.log(roomKey);
